// goal_action.php (add support for new goals, deposits, and withdrawals)
<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");
if ($conn->connect_error) die("DB error: " . $conn->connect_error);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['name'])) {
        // Add Goal
        $name = $conn->real_escape_string($_POST['name']);
        $desc = $conn->real_escape_string($_POST['description']);
        $cat  = $conn->real_escape_string($_POST['category']);
        $conn->query("INSERT INTO goals (Name, Description, Category, CurrentBalance) VALUES ('$name', '$desc', '$cat', 0)");
        header("Location: goals.php");
        exit;
    } elseif (isset($_POST['type']) && in_array($_POST['type'], ['Deposit', 'Withdraw'])) {
        // Add Deposit or Withdraw
        $type = $_POST['type'];
        $goal = $conn->real_escape_string($_POST['goal']);
        $amt = floatval($_POST['amount']);
        $date = $conn->real_escape_string($_POST['paydate']);
        $desc = $conn->real_escape_string($_POST['description']);

        $amt_signed = ($type === 'Withdraw') ? -$amt : $amt;

        $conn->query("INSERT INTO goalswd (Goal, Type, Amount, PayDate, Description) VALUES ('$goal', '$type', $amt, '$date', '$desc')");
        $conn->query("UPDATE goals SET CurrentBalance = CurrentBalance + ($amt_signed) WHERE Name = '$goal'");

        header("Location: goals.php");
        exit;
    }
}
?>
