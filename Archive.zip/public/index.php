<?php
// Entry point for the application
echo "Hello, World!";
