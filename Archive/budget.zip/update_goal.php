<script>
document.querySelectorAll('.save-goal').forEach(btn => {
  btn.addEventListener('click', () => {
    const id = btn.dataset.id;
    const field = 'Name';
    const value = btn.closest('.card-header').querySelector('[contenteditable]').innerText.trim();

    const formData = new FormData();
    formData.append('id', id);
    formData.append('field', field);
    formData.append('value', value);

    fetch('update_goals.php', {
      method: 'POST',
      body: formData
    })
    .then(r => r.text())
    .then(msg => alert(msg))
    .catch(err => alert("Error: " + err));
  });
});
</script>
