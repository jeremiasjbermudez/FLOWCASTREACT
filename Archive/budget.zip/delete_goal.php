<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = (int)$_POST['id'];
    $stmt = $conn->prepare("DELETE FROM goals WHERE ID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: goals.php");
    exit;
}
?>
