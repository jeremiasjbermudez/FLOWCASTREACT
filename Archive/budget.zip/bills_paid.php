<?php
$conn = new mysqli('localhost', 'admin', 'ti@A4pnc', 'PNCaccounts');
if ($conn->connect_error) die('Connection failed: ' . $conn->connect_error);

$accounts = ['spending' => 'Spending', 'reserve' => 'Reserve', 'growth' => 'Growth'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Bills Paid</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f0f4f8;
      padding: 20px;
      font-family: 'Segoe UI', sans-serif;
    }
    .header {
      background: linear-gradient(90deg, #2c3e50, #34495e);
      color: white;
      padding: 20px;
      border-radius: 12px;
      margin-bottom: 30px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    .header h1 { margin: 0; font-size: 2rem; }
    .table-wrapper {
      background: white;
      padding: 20px;
      border-radius: 16px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      margin-bottom: 30px;
    }
  </style>
</head>
<body>
<div class="header d-flex flex-wrap justify-content-between align-items-center">
    <h1>🪙Bills Paid Dashboard</h1>
    <div class="d-flex align-items-center gap-2">
    <a href="calendar.php" class="btn btn-outline-info btn-sm">📅 Calendar</a>
      <a href="update_tables.php" class="btn btn-outline-info    btn-sm">🔮 Update Accounts</a>
      <a href="bills.php" class="btn btn-outline-info btn-sm">💸 Bills</a>
      <a href="expenses.php" class="btn btn-outline-info btn-sm">💸 Expenses</a>
      <a href="deposits.php" class="btn btn-outline-info btn-sm">💰 Deposits</a>
      <a href="bills_paid.php" class="btn btn-outline-info btn-sm">📄 Bills Paid</a>
      <a href="forecast.php" class="btn btn-outline-info btn-sm">🔮 Forecast</a>
      <a href="goals.php" class="btn btn-outline-info btn-sm">⚽ Goals</a>
      <a href="index.php" class="btn btn-outline-info btn-sm">🏠 Back to Dashboard</a>
      <div class="search-bar ms-2">
        <input type="text" id="searchInput" class="form-control" placeholder="Search bills...">
      </div>
    </div>
  </div>
<!-- Add this button inside your .header button group -->
<div class="d-flex align-items-center gap-2">
<button class="btn btn-outline-secondary btn-sm" onclick="populateBillsPaid()">🧩 Populate Bills Paid</button>
</div>


<div class="d-flex flex-column gap-4">

<?php foreach ($accounts as $key => $label): ?>
  <div class="table-wrapper">
    <h3><?= $label ?> Bills Paid</h3>
    <table class="table table-striped" data-account="<?= $key ?>">
      <thead>
        <tr>
          <th>Description</th>
          <th>Amount</th>
          <th>Date</th>
          <th>Account</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $sql = "SELECT * FROM BillsPaid WHERE Account = '$key' ORDER BY Date DESC";
          $res = $conn->query($sql);
          while ($row = $res->fetch_assoc()):
        ?>
        <tr>
          <td><?= htmlspecialchars($row['Description']) ?></td>
          <td><?= htmlspecialchars($row['Amount']) ?></td>
          <td><?= htmlspecialchars($row['Date']) ?></td>
          <td><?= ucfirst($row['Account']) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
<?php endforeach; ?>

</div>

<?php $conn->close(); ?>

<script>
const searchInput = document.getElementById('searchInput');
const resultContainer = document.querySelector('.d-flex.flex-column');

function loadBillsPaid(query = '') {
  fetch(`fetch_bills_paid.php?search=${encodeURIComponent(query)}`)
    .then(res => res.text())
    .then(html => {
      resultContainer.innerHTML = html;
    });
}

searchInput.addEventListener('input', () => {
  loadBillsPaid(searchInput.value);
});

// Load all results on first visit
loadBillsPaid();
function populateBillsPaid() {
  fetch('populate_bills_paid.php')
    .then(res => res.text())
    .then(msg => {
      alert(msg || 'Bills Paid populated.');
      loadBillsPaid(); // Refresh the table
    });
}

</script>

</body>
</html>
