<?php
$conn = new mysqli('localhost', 'admin', 'ti@A4pnc', 'PNCaccounts');
if ($conn->connect_error) die("DB error: " . $conn->connect_error);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Goals Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f0f4f8; padding: 20px; font-family: 'Segoe UI', sans-serif; }
    .header {
      background: linear-gradient(90deg, #2c3e50, #34495e);
      color: white;
      padding: 20px;
      border-radius: 12px;
      margin-bottom: 30px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    .header h1 { margin: 0; font-size: 2rem; }
    .table-wrapper {
      background: white;
      padding: 20px;
      border-radius: 16px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      margin-bottom: 30px;
    }
    .form-control, .btn { border-radius: 10px; }
    .form-label { font-weight: 600; }
    td[contenteditable="true"]:focus { outline: 2px solid #3498db; background: #ecf0f1; }
    tfoot td { font-weight: bold; background: #f9f9f9; }
  </style>
</head>
<body>

<div class="header d-flex flex-wrap justify-content-between align-items-center">
  <h1 class="mb-0">⚽ Goals Dashboard</h1>
  <div class="d-flex align-items-center gap-2">
    <a href="calendar.php" class="btn btn-outline-info btn-sm">📅 Calendar</a>
    <a href="update_tables.php" class="btn btn-outline-info btn-sm">🔮 Update Accounts</a>
    <a href="bills.php" class="btn btn-outline-info btn-sm">💸 Bills</a>
    <a href="expenses.php" class="btn btn-outline-info btn-sm">💸 Expenses</a>
    <a href="deposits.php" class="btn btn-outline-info btn-sm">💰 Deposits</a>
    <a href="bills_paid.php" class="btn btn-outline-info btn-sm">📄 Bills Paid</a>
    <a href="forecast.php" class="btn btn-outline-info btn-sm">🔮 Forecast</a>
    <a href="goals.php" class="btn btn-outline-info btn-sm">⚽ Goals</a>
    <a href="index.php" class="btn btn-outline-info btn-sm">🏠 Back to Dashboard</a>
  </div>
</div>

<div class="table-wrapper">
  <!-- Add Goal Form -->
  <form id="goalForm" method="POST">
    <div class="row g-2 mb-4">
      <div class="col-md-4"><input type="text" name="name" class="form-control" placeholder="Name" required></div>
      <div class="col-md-4"><input type="text" name="description" class="form-control" placeholder="Description"></div>
      <div class="col-md-2"><input type="text" name="category" class="form-control" placeholder="Category"></div>
      <div class="col-md-2 d-grid">
        <button type="submit" class="btn btn-success">Add Goal</button>
      </div>
    </div>
  </form>

  <!-- Withdraw -->
  <form method="post" action="goal_action.php" class="mb-4">
    <input type="hidden" name="type" value="Withdraw">
    <div class="row g-2 align-items-end">
      <div class="col-md-3">
        <label class="form-label">Goal</label>
        <select name="goal" class="form-control" required>
          <?php
          $goals = $conn->query("SELECT Name FROM goals");
          while ($row = $goals->fetch_assoc()) {
              echo "<option value='{$row['Name']}'>{$row['Name']}</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label">Amount</label>
        <input type="number" name="amount" step="0.01" class="form-control" required>
      </div>
      <div class="col-md-2">
        <label class="form-label">Paydate</label>
        <input type="date" name="paydate" class="form-control" required>
      </div>
      <div class="col-md-3">
        <label class="form-label">Description</label>
        <input type="text" name="description" class="form-control" placeholder="Optional note">
      </div>
      <div class="col-md-2 d-grid">
        <label class="form-label">&nbsp;</label>
        <button type="submit" class="btn btn-danger">Withdraw</button>
      </div>
    </div>
  </form>

  <!-- Deposit -->
  <form method="post" action="goal_action.php" class="mb-4">
    <input type="hidden" name="type" value="Deposit">
    <div class="row g-2 align-items-end">
      <div class="col-md-3">
        <label class="form-label">Goal</label>
        <select name="goal" class="form-control" required>
          <?php
          $goals = $conn->query("SELECT Name FROM goals");
          $goals->data_seek(0);
          while ($row = $goals->fetch_assoc()) {
              echo "<option value='{$row['Name']}'>{$row['Name']}</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label">Amount</label>
        <input type="number" name="amount" step="0.01" class="form-control" required>
      </div>
      <div class="col-md-2">
        <label class="form-label">Paydate</label>
        <input type="date" name="paydate" class="form-control" required>
      </div>
      <div class="col-md-3">
        <label class="form-label">Description</label>
        <input type="text" name="description" class="form-control" placeholder="Optional note">
      </div>
      <div class="col-md-2 d-grid">
        <label class="form-label">&nbsp;</label>
        <button type="submit" class="btn btn-success">Deposit</button>
      </div>
    </div>
  </form>
</div>

<!-- Goal Cards (3 per row) -->
<div class="row">
  <?php
  $goalCards = $conn->query("SELECT * FROM goals");
  while ($goal = $goalCards->fetch_assoc()):
      $goalName = htmlspecialchars($goal['Name']);
      $category = htmlspecialchars($goal['Category']);
      $description = htmlspecialchars($goal['Description']);
      $balance = number_format($goal['CurrentBalance'], 2);

      $normalizedCategory = strtolower(trim($category));
      switch ($normalizedCategory) {
          case 'credit card': $headerClass = 'bg-info text-dark'; break;
          case 'savings':     $headerClass = 'bg-success bg-opacity-25 text-dark'; break;
          case 'emergency':   $headerClass = 'bg-danger bg-opacity-25 text-dark'; break;
          case 'vacation':    $headerClass = 'bg-warning bg-opacity-25 text-dark'; break;
          default:            $headerClass = 'bg-secondary bg-opacity-25 text-dark'; break;
      }

      $tx = $conn->query("SELECT * FROM goalswd WHERE Goal = '{$conn->real_escape_string($goal['Name'])}' ORDER BY PayDate DESC");
  ?>
  <div class="col-md-4 mb-4">
    <div class="card h-100 shadow-sm">
      <div class="card-header <?= $headerClass ?>">
        <h5 class="mb-0"><?php echo $goalName; ?></h5>
      </div>
      <div class="card-body">
        <p>
          <strong>Category:</strong> <?php echo $category; ?><br>
          <strong>Description:</strong> <?php echo $description; ?><br>
          <strong>Balance:</strong> $<?php echo $balance; ?>
        </p>
        <div class="table-responsive">
          <table class="table table-sm table-bordered table-striped mb-0">
            <thead class="table-light">
              <tr>
                <th>Type</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>
  <?php if ($tx->num_rows > 0): while ($row = $tx->fetch_assoc()): ?>
    <tr data-id="<?= $row['ID'] ?>">
      <td contenteditable="true" data-field="Type"><?= htmlspecialchars($row['Type']) ?></td>
      <td contenteditable="true" data-field="Amount"><?= number_format($row['Amount'], 2) ?></td>
      <td contenteditable="true" data-field="PayDate"><?= $row['PayDate'] ?></td>
      <td contenteditable="true" data-field="Description"><?= htmlspecialchars($row['Description']) ?></td>
      <td>
        <button class="btn btn-sm btn-primary save-entry">Save</button>
        <button class="btn btn-sm btn-danger delete-entry">Delete</button>
      </td>
    </tr>
  <?php endwhile; else: ?>
    <tr><td colspan="5" class="text-center text-muted">No transactions</td></tr>
  <?php endif; ?>
</tbody>

          </table>
        </div>
      </div>
    </div>
  </div>
  <?php endwhile; ?>
</div>

</body>
</html>
