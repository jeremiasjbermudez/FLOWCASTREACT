<?php
// fetch_forecast.php

ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    ob_start();
    include __DIR__ . '/db_refresh_forecast.php';
    ob_end_clean();
} catch (Throwable $e) {
    // fail silently
}

$conn = new mysqli('localhost', 'admin', 'ti@A4pnc', 'PNCaccounts');
if ($conn->connect_error) {
    die("<div class='alert alert-danger'>DB connection failed: {$conn->connect_error}</div>");
}

$q     = isset($_GET['q'])     ? $conn->real_escape_string($_GET['q'])     : '';
$start = isset($_GET['start']) ? $conn->real_escape_string($_GET['start']) : '';
$end   = isset($_GET['end'])   ? $conn->real_escape_string($_GET['end'])   : '';

$whereClauses = [];
if ($q !== '') {
    $like = "%{$q}%";
    $whereClauses[] = "(`Date` LIKE '$like' OR `Description` LIKE '$like')";
}
if ($start !== '') {
    $whereClauses[] = "`Date` >= '$start'";
}
if ($end !== '') {
    $whereClauses[] = "`Date` <= '$end'";
}
$whereSql = count($whereClauses) ? ' AND ' . implode(' AND ', $whereClauses) : '';

$accounts = [
    'spending' => '💳 Spending',
    'reserve'  => '🛡️ Reserve',
    'growth'   => '📈 Growth'
];

// Pre-calculate total net across all accounts
$totalNetAll = 0;
$nets = [];

foreach (array_keys($accounts) as $acctKey) {
    $sql = "
        SELECT
            COALESCE(SUM(Deposits),0) AS total_deposits,
            COALESCE(SUM(Withdrawals),0) AS total_withdrawals
        FROM Forecast
        WHERE Account = '$acctKey' $whereSql
    ";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $net = $row['total_deposits'] - $row['total_withdrawals'];
    $nets[$acctKey] = [
        'deposits' => $row['total_deposits'],
        'withdrawals' => $row['total_withdrawals'],
        'net' => $net
    ];
    $totalNetAll += $net;
}

echo "<div class='row gx-4'>";

echo "<div class='row gx-4'>";

foreach ($accounts as $acctKey => $acctLabel) {
    echo "<div class='col-md-4'>";

    // Add top card only once above spending
    if ($acctKey === 'spending') {
        echo "
        <div class='card mb-3 shadow-sm' style='background-color: #e6ccff; border: 1px solid #c9a6ff;'>
          <div class='card-body'>
            <h6 class='card-title mb-1'>🧿 Combined Net Forecast</h6>
            <p class='card-text fs-5 mb-0'><strong>Total:</strong> $" . number_format($totalNetAll, 2) . "</p>
          </div>
        </div>
        ";
    }

    // Add invisible spacer cards for reserve and growth
    if ($acctKey === 'reserve' || $acctKey === 'growth') {
        echo "<div class='mb-3' style='height: 96px;'></div>";
    }

    $colorMap = [
        'spending' => '#d0ebff',
        'reserve'  => '#d3f9d8',
        'growth'   => '#fff3bf'
    ];
    $bg = $colorMap[$acctKey];

    $tot = $nets[$acctKey];
    $net = $tot['net'];

    echo "
    <div class='summary-bar p-3 rounded shadow-sm mb-3' style='background-color: {$bg};'>
      <h5 class='mb-2'>{$acctLabel} Net Forecast</h5>
      <div>
        <strong>Deposits:</strong> $" . number_format($tot['deposits'], 2) . "<br>
        <strong>Withdrawals:</strong> $" . number_format($tot['withdrawals'], 2) . "<br>
        <strong>Net:</strong> <span class='" . ($net < 0 ? 'text-danger' : 'text-success') . "'>$" . number_format($net, 2) . "</span>
      </div>
    </div>
    ";

    echo "
    <div class='table-wrapper bg-white p-3 rounded shadow-sm'>
      <table class='table table-hover table-bordered mb-0'>
        <thead class='table-light'><tr>
          <th>Date</th><th>Description</th><th>Withdrawals</th><th>Deposits</th>
        </tr></thead>
        <tbody>
    ";

    $sql = "
      SELECT `Date`,`Description`,`Withdrawals`,`Deposits`
      FROM `Forecast`
      WHERE `Account` = '$acctKey' $whereSql
      ORDER BY `Date` DESC
    ";
    $res = $conn->query($sql);
    if ($res && $res->num_rows) {
        while ($r = $res->fetch_assoc()) {
            echo "<tr>
                    <td>{$r['Date']}</td>
                    <td>{$r['Description']}</td>
                    <td>{$r['Withdrawals']}</td>
                    <td>{$r['Deposits']}</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='4'>No records found.</td></tr>";
    }

    echo "</tbody></table></div></div>"; // close col
}

echo "</div>"; // close row




$conn->close();
