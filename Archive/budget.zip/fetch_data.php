<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$tables = ['Spending', 'Reserve', 'Growth'];
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

foreach ($tables as $table) {
    echo "<div class='table-wrapper'><h3>$table Account</h3>";
    echo "<table class='table table-hover table-bordered'><thead class='table-light'>
            <tr><th>Date</th><th>Description</th><th>Withdrawals</th><th>Deposits</th><th>Category</th><th>Balance</th></tr>
          </thead><tbody>";
    
    // Use SHOW COLUMNS to check if 'Category' exists
    $columnsResult = $conn->query("SHOW COLUMNS FROM $table");
    $hasCategory = false;
    if ($columnsResult) {
        while ($col = $columnsResult->fetch_assoc()) {
            if ($col['Field'] === 'Category') {
                $hasCategory = true;
                break;
            }
        }
    }

    $query = "SELECT * FROM $table";
    if ($search) {
        if ($hasCategory) {
            $query .= " WHERE Description LIKE '%$search%' OR Category LIKE '%$search%'";
        } else {
            $query .= " WHERE Description LIKE '%$search%'";
        }
    }

    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['Date']}</td>
                    <td>{$row['Description']}</td>
                    <td>{$row['Withdrawals']}</td>
                    <td>{$row['Deposits']}</td>
                    <td>" . ($hasCategory ? ($row['Category'] ?? '') : '') . "</td>
                    <td>{$row['Balance']}</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No records found.</td></tr>";
    }
    echo "</tbody></table></div>";
}
$conn->close();
?>