<?php
// forecast.php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Forecast Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f0f4f8;
      padding: 20px;
      font-family: 'Segoe UI', sans-serif;
    }
    .header {
      background: linear-gradient(90deg, #2c3e50, #34495e);
      color: white;
      padding: 20px;
      border-radius: 12px;
      margin-bottom: 30px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
    .header h1 { margin: 0; font-size: 2rem; }
    .table-wrapper {
      background: white;
      padding: 20px;
      border-radius: 16px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      flex: 1 1 32%;
      min-width: 300px;
      max-width: 100%;
      overflow-x: auto;
    }
    @media print {
      body { background: white; color: black; }
      .header, .btn, .text-end { display: none !important; }
      .table-wrapper { box-shadow: none !important; border: none !important; }
      .table { font-size: 12px; }
      a::after { content: ""; }
    }
  </style>
</head>
<body>

<div class="header d-flex justify-content-between align-items-center">
  <h1>🧙‍♂️Forecast Dashboard</h1>
  <div class="d-flex align-items-center gap-2">
    <button onclick="window.print()" class="btn btn-outline-warning text-dark">🖨️ Print</button>
    <a href="calendar.php" class="btn btn-outline-info btn-sm">📅 Calendar</a>
      <a href="update_tables.php" class="btn btn-outline-info    btn-sm">🔮 Update Accounts</a>
      <a href="bills.php" class="btn btn-outline-info btn-sm">💸 Bills</a>
      <a href="expenses.php" class="btn btn-outline-info btn-sm">💸 Expenses</a>
      <a href="deposits.php" class="btn btn-outline-info btn-sm">💰 Deposits</a>
      <a href="bills_paid.php" class="btn btn-outline-info btn-sm">📄 Bills Paid</a>
      <a href="forecast.php" class="btn btn-outline-info btn-sm">🔮 Forecast</a>
      <a href="goals.php" class="btn btn-outline-info btn-sm">⚽ Goals</a>
      <a href="index.php" class="btn btn-outline-info btn-sm">🏠 Back to Dashboard</a>
    <div class="search-bar ms-2">
      <input type="text" id="forecastSearch" class="form-control" placeholder="Search Forecast...">
    </div>
  </div>
</div>

<div class="mb-3">
  <h5 class="mb-2">Forecasted budget by date range:</h5>
  <div class="controls d-flex gap-2">
    <input type="date" id="startDate" class="form-control">
    <input type="date" id="endDate" class="form-control">
  </div>
</div>


<div id="forecastContainer">
  <?php include __DIR__ . '/fetch_forecast.php'; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const startInput = document.getElementById('startDate');
  const endInput = document.getElementById('endDate');
  const searchInput = document.getElementById('forecastSearch');

  function updateForecastAndSummary() {
    const start = startInput.value;
    const end = endInput.value;
    const q = searchInput.value;

    const params = new URLSearchParams();
    if (start) params.append('start', start);
    if (end) params.append('end', end);
    if (q) params.append('q', q);

    fetch(`fetch_forecast.php?${params.toString()}`)
      .then(res => res.text())
      .then(html => {
        document.getElementById('forecastContainer').innerHTML = html;

        // Extract Net values using regex
        const getNet = (label) => {
          const match = html.match(new RegExp(`${label} Net Forecast.*?Net:</strong>.*?\\$(\\d{1,3}(?:,\\d{3})*(?:\\.\\d{2})?)`, 'i'));
          return match ? match[1] : '0.00';
        };

        document.getElementById('summarySpending').textContent = getNet('Spending');
        document.getElementById('summaryReserve').textContent  = getNet('Reserve');
        document.getElementById('summaryGrowth').textContent   = getNet('Growth');
      });
  }

  startInput.addEventListener('change', updateForecastAndSummary);
  endInput.addEventListener('change', updateForecastAndSummary);
  searchInput.addEventListener('input', updateForecastAndSummary);

  updateForecastAndSummary(); // Initial load
});
</script>

</body>
</html>
