<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $goal = $_POST["goal"];
    $amount = floatval($_POST["amount"]);
    $paydate = $_POST["paydate"];
    $desc = $_POST["description"];
    $type = $_POST["type"]; // "Deposit" or "Withdraw"

    // ✅ Insert into goalswd
    $stmt = $conn->prepare("INSERT INTO goalswd (Goal, Type, Amount, PayDate, Description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdss", $goal, $type, $amount, $paydate, $desc);
    $stmt->execute();

    // ✅ Update the goals table
    if ($type === 'Deposit') {
        $conn->query("UPDATE goals 
            SET Deposits = Deposits + $amount,
                TotalDCount = TotalDCount + 1,
                CurrentBalance = CurrentBalance + $amount
            WHERE Name = '$goal'");
    } elseif ($type === 'Withdraw') {
        $conn->query("UPDATE goals 
            SET Withdraws = Withdraws + $amount,
                TotalWCount = TotalWCount + 1,
                CurrentBalance = CurrentBalance - $amount
            WHERE Name = '$goal'");
    }

    header("Location: goals.php?success=1");
    exit;
}
?>
