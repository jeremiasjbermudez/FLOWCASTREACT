<?php
$conn = new mysqli('localhost', 'admin', 'ti@A4pnc', 'PNCaccounts');
if ($conn->connect_error) die('Connection failed: ' . $conn->connect_error);

$accounts = ['spending' => 'Spending', 'reserve' => 'Reserve', 'growth' => 'Growth'];
$q = $_GET['q'] ?? '';
$start = $_GET['start'] ?? '';
$end = $_GET['end'] ?? '';

// Get current month range
$currentStart = date('Y-m-01');
$currentEnd = date('Y-m-t');

// Fetch BillsPaid descriptions for current month
$paidMatches = [];
$res = $conn->query("SELECT Description FROM BillsPaid WHERE Date BETWEEN '$currentStart' AND '$currentEnd'");
while ($row = $res->fetch_assoc()) {
  $paidMatches[] = strtolower($row['Description']);
}

$where = "";
if ($q) {
  $safe = $conn->real_escape_string($q);
  $where .= " AND (Bill LIKE '%$safe%' OR ContainsText LIKE '%$safe%')";
}
if ($start) $where .= " AND DayOfMonth >= '$start'";
if ($end) $where .= " AND DayOfMonth <= '$end'";


echo "<div class='d-flex flex-column gap-4'>";

foreach ($accounts as $key => $label) {
  echo "<div class='table-wrapper mb-4'>
          <div class='d-flex justify-content-between align-items-center'>
            <h3 class='mb-0'>$label Bills</h3>
            <div>
              <a href='export_bills.php?account=$key&start=$start&end=$end&q=$q' class='btn btn-outline-secondary btn-sm'>Export CSV</a>
              <button class='btn btn-outline-secondary btn-sm' onclick='resetToMonth()'>Show All</button>
            </div>
          </div>
<table class='table table-striped table-$key' data-account='$key'>
            <thead class='table-light'>
              <tr>
                <th>Bill</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Account</th>
                <th>ContainsText</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>";

  $sql = "SELECT * FROM Bills WHERE Account = '$key' $where ORDER BY DayOfMonth DESC";
  $res = $conn->query($sql);
  $total = 0;

  while ($row = $res->fetch_assoc()) {
    $highlight = '';
    $contains = strtolower($row['ContainsText']);
    $billDate = $row['DayOfMonth'];
    $total += floatval($row['Amount']);

    if ($billDate >= $currentStart && $billDate <= $currentEnd) {
      foreach ($paidMatches as $desc) {
        if (strpos($desc, $contains) !== false && $contains != '') {
          $highlight = 'table-success';
          break;
        }
      }
    }

    echo "<tr class='$highlight' data-id='{$row['id']}'>
            <td class='Bill' contenteditable='true'>" . htmlspecialchars($row['Bill']) . "</td>
            <td class='Amount' contenteditable='true'>" . htmlspecialchars($row['Amount']) . "</td>
            <td class='DayOfMonth' contenteditable='true'>" . htmlspecialchars($row['DayOfMonth']) . "</td>
            <td class='Account'>
              <select class='form-select form-select-sm Account-inp' disabled>
                <option value='spending'" . ($row['Account'] == 'spending' ? ' selected' : '') . ">Spending</option>
                <option value='reserve'" . ($row['Account'] == 'reserve' ? ' selected' : '') . ">Reserve</option>
                <option value='growth'" . ($row['Account'] == 'growth' ? ' selected' : '') . ">Growth</option>
              </select>
            </td>
            <td class='ContainsText' contenteditable='true'>" . htmlspecialchars($row['ContainsText']) . "</td>
            <td>
              <button class='btn btn-sm btn-primary edit-btn'>Edit</button>
              <button class='btn btn-sm btn-success save-btn d-none'>Save</button>
              <button class='btn btn-sm btn-danger delete-btn'>Delete</button>
            </td>
          </tr>";
  }

  echo "</tbody>
          <tfoot><tr><td><strong>Total</strong></td><td colspan='5'>$" . number_format($total, 2) . "</td></tr></tfoot>
        </table>
      </div>";
}

echo "</div>";
$conn->close();
?>
