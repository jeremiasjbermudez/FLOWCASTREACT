<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Ensure BillsPaid table exists
$conn->query("CREATE TABLE IF NOT EXISTS BillsPaid (
    id INT AUTO_INCREMENT PRIMARY KEY,
    SourceTable VARCHAR(50),
    MatchText VARCHAR(255),
    Description TEXT,
    Date DATE,
    Amount DECIMAL(15,2),
    Account VARCHAR(255)
)");

// Get all ContainsText values from bills table
$bills = $conn->query("SELECT ContainsText, Account FROM bills WHERE ContainsText IS NOT NULL AND ContainsText != ''");

if (!$bills) {
    die("Failed to fetch from bills table: " . $conn->error);
}

$tables = ['Spending', 'Reserve', 'Growth'];

while ($bill = $bills->fetch_assoc()) {
    $matchText = $conn->real_escape_string($bill['ContainsText']);
    $billAccount = $conn->real_escape_string($bill['Account']);
    
    foreach ($tables as $table) {
        $query = "SELECT Date, Description, Withdrawals, Deposits FROM $table WHERE Description LIKE '%$matchText%'";
        $res = $conn->query($query);

        if ($res === false) {
            echo "Error querying $table: " . $conn->error . "<br>";
            continue;
        }

        while ($row = $res->fetch_assoc()) {
            $amount = !empty($row['Withdrawals']) ? $row['Withdrawals'] : $row['Deposits'];

            // Check for duplicates
            $desc = $conn->real_escape_string($row['Description']);
            $date = $conn->real_escape_string($row['Date']);
            $check = $conn->query("SELECT 1 FROM BillsPaid WHERE Description = '$desc' AND Date = '$date' AND Account = '$billAccount'");

            if ($check && $check->num_rows > 0) {
                continue; // Skip duplicate
            }

            $stmt = $conn->prepare("INSERT INTO BillsPaid (SourceTable, MatchText, Description, Date, Amount, Account) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssds", $table, $matchText, $row['Description'], $row['Date'], $amount, $billAccount);
            $stmt->execute();
            $stmt->close();
        }
    }
}

echo "✅ BillsPaid table populated (duplicates avoided).";
$conn->close();
?>