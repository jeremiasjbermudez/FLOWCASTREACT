
<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");
$id = intval($_POST['id'] ?? 0);
if ($id) $conn->query("DELETE FROM Goals WHERE ID = $id");
$conn->close();
