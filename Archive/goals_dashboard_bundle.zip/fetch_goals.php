
<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");
$q = $conn->real_escape_string($_GET['q'] ?? '');
$sql = "SELECT * FROM Goals WHERE Name LIKE '%$q%' ORDER BY ID DESC";
$result = $conn->query($sql);

echo "<table class='table table-bordered table-sm'><thead><tr>";
$fields = ['Name', 'Description', 'Category', 'CurrentBalance', 'TotalPymnts', 'NumPymnts', 'AmtPerPmnt', 'PayDates', 'Expenses', 'InterestRate', 'Documents'];
for ($i = 1; $i <= 10; $i++) $fields[] = "Custom$i";
echo "<th>ID</th>";
foreach ($fields as $f) echo "<th>$f</th>";
echo "<th>Actions</th></tr></thead><tbody>";

while ($row = $result->fetch_assoc()) {
  echo "<tr data-id='{$row['ID']}'>";
  echo "<td>{$row['ID']}</td>";
  foreach ($fields as $f) {
    $v = htmlspecialchars($row[$f]);
    echo "<td contenteditable='true' data-field='$f'>$v</td>";
  }
  echo "<td><button onclick='deleteGoal({$row['ID']})' class='btn btn-sm btn-danger'>Delete</button></td></tr>";
}
echo "</tbody></table>";
$conn->close();
