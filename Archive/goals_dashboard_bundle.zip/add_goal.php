
<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");

$name = $conn->real_escape_string($_POST['name'] ?? '');
$desc = $conn->real_escape_string($_POST['description'] ?? '');
$cat = $conn->real_escape_string($_POST['category'] ?? '');

$conn->query("INSERT INTO Goals (Name, Description, Category) VALUES ('$name', '$desc', '$cat')");
$conn->close();
