
<?php
$conn = new mysqli("localhost", "admin", "ti@A4pnc", "PNCaccounts");

$id = intval($_POST['id'] ?? 0);
$field = $conn->real_escape_string($_POST['field'] ?? '');
$value = $conn->real_escape_string($_POST['value'] ?? '');

$allowed = ['Name','Description','Category','CurrentBalance','TotalPymnts','NumPymnts','AmtPerPmnt','PayDates','Expenses','InterestRate','Documents'];
for ($i = 1; $i <= 10; $i++) $allowed[] = "Custom$i";

if ($id && in_array($field, $allowed)) {
  $conn->query("UPDATE Goals SET $field = '$value' WHERE ID = $id");
}
$conn->close();
